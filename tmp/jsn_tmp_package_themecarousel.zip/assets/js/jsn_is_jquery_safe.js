try { 
		if (typeof(jQuery)=='function')
		{ 
			var JSNISjQueryBefore = jQuery; 
		}
} catch (e) {}