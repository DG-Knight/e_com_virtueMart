DROP TABLE IF EXISTS `#__imageshow_theme_carousel`;

